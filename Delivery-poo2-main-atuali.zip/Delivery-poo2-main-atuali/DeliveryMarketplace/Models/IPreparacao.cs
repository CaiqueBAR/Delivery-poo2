namespace DeliveryMarketplace.Models;

/// <summary>
/// Contrato de quem precisa ser preparado na cozinha.
/// Só o Prato implementa: a Bebida é servida pronta e não passa pelo preparo.
/// </summary>
/// 

///INTERFACE CRIADA CONFORME O DIAGRAMA DE CLASSES, 12/11
public interface IPreparacao
{
    void Preparar();
}
