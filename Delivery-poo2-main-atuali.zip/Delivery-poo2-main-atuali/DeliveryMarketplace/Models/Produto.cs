namespace DeliveryMarketplace.Models;

public class Categoria
{
    public int Id { get; set; }
    public string Nome { get; set; } = "";

    public int RestauranteId { get; set; }
    public Restaurante? Restaurante { get; set; }

    public override string ToString() => Nome;
}


/// No banco, as duas ficam na mesma tabela (Produtos), diferenciadas pela coluna TipoProduto.

/// CRIAÇÃO DA CLASSE ABSTRATA PRODUTO, PRATO HERDA DE PRODUTO E BEBIDA TAMBÊM. 12/11
public abstract class Produto
{
    public int Id { get; set; }
    public string Nome { get; set; } = "";
    public string Descricao { get; set; } = "";
    public decimal Preco { get; set; }
    public bool Disponivel { get; set; } = true;

    public int RestauranteId { get; set; }
    public Restaurante? Restaurante { get; set; }

    public int CategoriaId { get; set; }
    public Categoria? Categoria { get; set; }

    public string CategoriaNome => Categoria?.Nome ?? "";
    public string SituacaoTexto => Disponivel ? "Disponível" : "Indisponível";

    /// <summary>Nome do tipo, mostrado na tela. Cada subclasse define o seu.</summary>
    public abstract string TipoTexto { get; }

    /// <summary>Informação específica do tipo (tempo de preparo ou volume).</summary>
    public abstract string DetalheTexto { get; }

    /// <summary>Valor do campo específico (minutos ou ml), usado no formulário de edição.</summary>
    public abstract int Detalhe { get; set; }
}

public class Prato : Produto, IPreparacao
{
    public int TempoPreparoMinutos { get; set; } = 20;

    /// <summary>Chamado pelo restaurante quando o pedido entra em preparo.</summary>
    public void Preparar()
    {
        System.Diagnostics.Debug.WriteLine($"Preparando {Nome} (cerca de {TempoPreparoMinutos} min)");
    }

    public override string TipoTexto => "Prato";
    public override string DetalheTexto => $"{TempoPreparoMinutos} min de preparo";
    public override int Detalhe
    {
        get => TempoPreparoMinutos;
        set => TempoPreparoMinutos = value;
    }
}

public class Bebida : Produto
{
    public int VolumeMl { get; set; } = 350;

    public override string TipoTexto => "Bebida";
    public override string DetalheTexto => $"{VolumeMl} ml";
    public override int Detalhe
    {
        get => VolumeMl;
        set => VolumeMl = value;
    }
}
